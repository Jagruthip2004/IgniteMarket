# Fundify-Backend
A crowdfunding platform made with mongoDB atlas and google cloud storage
Google cloud storage used for media storage
