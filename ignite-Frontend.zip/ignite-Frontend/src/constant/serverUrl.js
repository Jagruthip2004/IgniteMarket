export const SERVER_URL = 'https://fundify.onrender.com';
